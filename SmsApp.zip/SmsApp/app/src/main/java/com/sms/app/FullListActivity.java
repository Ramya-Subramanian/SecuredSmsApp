package com.sms.app;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.sms.app.databinding.ActivityFullListBinding;
import com.sms.app.databinding.ActivitySmsTriggerBinding;
import com.sms.app.model.SmsModel;

import java.util.ArrayList;
import java.util.List;

public class FullListActivity extends AppCompatActivity {
    private AppUtils appUtils;
    private List<SmsModel> list = new ArrayList<>();
    private SmsListAdapter adapter;
    private ActivityFullListBinding binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFullListBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        appUtils = new AppUtils();
        loadRecentSms();

    }

    private void loadRecentSms() {
        try {
        }catch (Exception e){

        }
        list = appUtils.getTempList(FullListActivity.this,true);
        adapter = new SmsListAdapter(FullListActivity.this, list);
        binding.smsFullList.setLayoutManager(new LinearLayoutManager(FullListActivity.this));
        binding.smsFullList.setAdapter(adapter);
        if (list.size() == 0){
            binding.recentMsgStatus.setVisibility(View.VISIBLE);
            binding.smsFullList.setVisibility(View.GONE);
        }else {
            binding.recentMsgStatus.setVisibility(View.GONE);
            binding.smsFullList.setVisibility(View.VISIBLE);
        }
    }

}
