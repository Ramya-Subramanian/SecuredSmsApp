package com.sms.app;

import static android.content.Context.MODE_PRIVATE;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sms.app.model.SmsModel;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AppUtils {

    public boolean isSmsPermissionEnabled(Context context){
       return ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED;
    }
    public List<SmsModel> showRecentSms(Context context) {
        List<SmsModel> smsList = new ArrayList<>();
        ContentResolver contentResolver = context.getContentResolver();
        Cursor cursor = contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                null,
                null,
                null,
                null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String address = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.ADDRESS));
                String body = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.BODY));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.DATE));
                smsList.add(new SmsModel(body, address, date));
            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();
        }
        Log.d("_MSG_", "" + smsList.toString());
        return smsList;
    }
    interface SmsListener{
        void onSmsTriggered();
    }
    public void sendSms(String msg, String mobileNumber, Context context,SmsListener smsListener) {
        try {
            String encryptedMsg = new AESUtils().encryptStr(msg,context);
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(mobileNumber, null, encryptedMsg, null, null);
            SmsModel smsModel = new SmsModel(encryptedMsg,mobileNumber,"");
            setTempList(smsModel,context);
            Toast.makeText(context, "SMS Shared Successfully !", Toast.LENGTH_SHORT).show();
            smsListener.onSmsTriggered();
        } catch (Exception e) {
            Toast.makeText(context, "Something Went Wrong !", Toast.LENGTH_SHORT).show();
        }

    }

    public static final String tempSmsList = "tempSmsList";
    public static final String tempSmsListPref = "tempSmsListPref";

    public List<SmsModel> getTempList(Context context,boolean isSortingRequired) {
        Gson gson = new Gson();
        List<SmsModel> productFromShared = new ArrayList<>();
        SharedPreferences sharedPref = context.getSharedPreferences(tempSmsListPref, Context.MODE_PRIVATE);
        String jsonPreferences = sharedPref.getString(tempSmsList, "");
        Type type = new TypeToken<List<SmsModel>>() {
        }.getType();
        productFromShared = gson.fromJson(jsonPreferences, type);
        if (productFromShared!=null && isSortingRequired) {
            Collections.reverse(productFromShared);
        }
        if (productFromShared == null){
            productFromShared = new ArrayList<>();
        }
        return productFromShared;
    }

    private  void setTempList(SmsModel recentSms, Context context) {
        try {
            List<SmsModel> tempList = getTempList(context,false);
            tempList.add(recentSms);
            Gson gson = new Gson();
            String smsListString = gson.toJson(tempList);
            SharedPreferences sharedPref = context.getSharedPreferences(tempSmsListPref, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString(tempSmsList, smsListString);
            //editor.apply();
            editor.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
