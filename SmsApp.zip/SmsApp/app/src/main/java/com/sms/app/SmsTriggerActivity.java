package com.sms.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.Telephony;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.sms.app.databinding.ActivitySmsTriggerBinding;
import com.sms.app.model.SmsModel;

import java.io.Console;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SmsTriggerActivity extends AppCompatActivity {

    private ActivitySmsTriggerBinding binding;
    private static final int READ_SMS_PERMISSION_CODE = 1;
    private List<SmsModel> list = new ArrayList<>();
    private SmsListAdapter adapter;
    AppUtils appUtils;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySmsTriggerBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        appUtils = new AppUtils();
        handleSmsPermission();
        binding.sendSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendSms();
            }
        });
        binding.showAllMsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), FullListActivity.class);
                startActivity(i);
            }
        });
        //loadRecentSms();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadRecentSms();
        if (!appUtils.isSmsPermissionEnabled(SmsTriggerActivity.this)){
           binding.smsPermissionStatus.setVisibility(View.VISIBLE);
           binding.sendSms.setEnabled(false);
        }else {
            binding.smsPermissionStatus.setVisibility(View.GONE);
            binding.sendSms.setEnabled(true);
        }

    }

    private void loadRecentSms(){
        list = appUtils.getTempList(SmsTriggerActivity.this,true);
        if (list.size() > 3){
            list = list.subList(0,3);
        }
        adapter = new SmsListAdapter(SmsTriggerActivity.this,list);
        binding.smsList.setLayoutManager(new LinearLayoutManager(SmsTriggerActivity.this));
        binding.smsList.setAdapter(adapter);

        if (list.size() == 0){
            binding.recentMsgStatus.setVisibility(View.VISIBLE);
            binding.smsList.setVisibility(View.GONE);
        }else {
            binding.recentMsgStatus.setVisibility(View.GONE);
            binding.smsList.setVisibility(View.VISIBLE);
        }
    }


    private void sendSms(){
        String msg = binding.sms.getText().toString().trim();
        String phone = binding.mobileNumber.getText().toString().trim();
        if (TextUtils.isEmpty(msg) || TextUtils.isEmpty(phone)){
            Toast.makeText(SmsTriggerActivity.this, "Message & Mobile Number Should Not Be Empty !", Toast.LENGTH_SHORT).show();
            return;
        }
        if (phone.length() <= 9){
            Toast.makeText(SmsTriggerActivity.this, "Enter Valid Mobile Number", Toast.LENGTH_SHORT).show();
            return;
        }
        appUtils.sendSms(msg, phone, SmsTriggerActivity.this, new AppUtils.SmsListener() {
            @Override
            public void onSmsTriggered() {
                binding.sms.setText("");
                binding.mobileNumber.setText("");
                loadRecentSms();
            }
        });

    }


    private void handleSmsPermission() {
        if (!appUtils.isSmsPermissionEnabled(SmsTriggerActivity.this)) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS}, READ_SMS_PERMISSION_CODE);

        } else {
            appUtils.showRecentSms(SmsTriggerActivity.this);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == READ_SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                appUtils.showRecentSms(SmsTriggerActivity.this);
            }else {
                Toast.makeText(this, "Permission Denied !", Toast.LENGTH_SHORT).show();
            }
        }
    }

}