package com.sms.app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sms.app.model.SmsModel;

import java.util.List;

public class SmsListAdapter extends RecyclerView.Adapter<SmsListAdapter.ViewHolder> {
    private List<SmsModel> mData;
    private LayoutInflater mInflater;
    private Context context;
    SmsListAdapter(Context context, List<SmsModel> data) {
        this.mInflater = LayoutInflater.from(context);
        this.mData = data;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.sms_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        SmsModel sms = mData.get(position);
        holder.smsDate.setText(sms.getDate());
        holder.smsSender.setText("To - "+sms.getSender());
        String decryptedMsg = "";
        try {
            decryptedMsg = new AESUtils().decryptStr(sms.getMessage(),context);
        }catch (Exception e){
            decryptedMsg = sms.getSender();
        }

        holder.smsMsg.setText(decryptedMsg);
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView smsDate, smsSender, smsMsg;
        ViewHolder(View itemView) {
            super(itemView);
            smsDate = itemView.findViewById(R.id.smsDate);
            smsSender = itemView.findViewById(R.id.smsSender);
            smsMsg = itemView.findViewById(R.id.smsMsg);
        }

    }

}
