package com.sms.app


import android.content.Context
import android.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

class AESUtils {
    private val sal = "73A70181E1D81B8E"
    private val nJx = "C0BAE23DF8B51807B3E17D21925FADF2"
    fun encryptStr(data: String, context: Context) = encryptWithPadding(data, nJx)
    fun decryptStr(data: String, context: Context) = decryptWithPadding(data, nJx)

    @Throws(Exception::class)
    private fun decryptWithPadding(data: String, password: String): String {

        val cipher = Cipher.getInstance("AES/CBC/PKCS7Padding")
        cipher.init(
            Cipher.DECRYPT_MODE,
            SecretKeySpec(password.toByteArray(Charsets.UTF_8), "AES"),
            IvParameterSpec(sal.toByteArray(Charsets.UTF_8))
        )
        return cipher.doFinal(Base64.decode(data, Base64.NO_WRAP))
            .toString(Charsets.UTF_8)
            .replace(0.toChar().toString(), "")


    }

    @Throws(Exception::class)
    private fun encryptWithPadding(data: String, password: String): String {

        val cipher = Cipher.getInstance("AES/CBC/PKCS7Padding")
        cipher.init(
            Cipher.ENCRYPT_MODE,
            SecretKeySpec(password.toByteArray(Charsets.UTF_8), "AES"),
            IvParameterSpec(sal.toByteArray(Charsets.UTF_8))
        )
        return Base64.encode(cipher.doFinal(addZeroBytes(data)), Base64.NO_WRAP)
            .toString(Charsets.UTF_8)

    }

    @Throws(Exception::class)
    fun addZeroBytes(data: String): ByteArray {
        val plainBytes = data.toByteArray(Charsets.UTF_8)
        return if (plainBytes.size % 16 != 0) {
            val paddedBytes = ByteArray((plainBytes.size / 16 + 1) * 16)
            System.arraycopy(plainBytes, 0, paddedBytes, 0, plainBytes.size)
            paddedBytes
        } else {
            plainBytes
        }
    }
}